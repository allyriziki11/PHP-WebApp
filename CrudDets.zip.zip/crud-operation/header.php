<?php 
    //include("session.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Welcome to CRUD in PHP</title>
	<link rel="icon" href="images/download.jpg" type="image/jpg">
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css" />
    <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
    <script src="http://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style type="text/css">
		.box{
			background: #f0f0f0;
			padding: 20px;
		}
		.fa {
  padding: 5px;
  font-size: 15px;
  width: 20px;
  text-align: center;
  text-decoration: none;
  margin: 2px 1px;
  border-radius: 3px;
}

.fa:hover {
    opacity: 0.7;
}

.fa-facebook {
  background: #3B5998;
  color: white;
}

.fa-twitter {
  background: #55ACEE;
  color: white;
}

.fa-google {
  background: #dd4b39;
  color: white;
}
.fa-instagram {
  background: #C13584;
  color: white;
}
.fa-yahoo {
  background: #430297;
  color: white;
}
	</style>
</head>
<body> 

<div class="container"> 
  <nav class="navbar navbar-default">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="index.php">CRUD</a>
      </div>
      <div id="navbar" class="navbar-collapse collapse">
        <ul class="nav navbar-nav">
          <li class="active"><a href="index.php">Home</a></li>
          <li><a href="insert.php">Add User</a></li> 
          <li><a href="users.php">All Users</a></li>
          <!-- <li>Welcome: <?php //echo $login_session; ?></li>
          <li><a href="logout.php">Sign out</a></li>-->
        </ul>
        
      </div><!--/.nav-collapse -->
    </div><!--/.container-fluid -->
  </nav> 
</div>