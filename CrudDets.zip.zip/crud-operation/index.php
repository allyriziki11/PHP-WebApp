<?php 

/*******************************************************************************************************
 
 I created this script in order to help other developers  or aspiring programmers to start working with
 PHP database. This code is distributed for free (without charge). You may copy, distribute and use it at your own risk. Take note that this code contains basic implementation of CRUD in PHP and we do not have any obligation if
 any circumstance will happen because of using this software.

 If you have any question, please don't hesitate to contact us. 

 Happy coding friend.

 Date created : January 17, 2018
 Author : Samuel
 *******************************************************************/

 require_once 'header.php';
?>
<div class="container">
	<div class="jumbotron">
	<h1>Basic CRUD in PHP</h1>
	<p>Create, Read, Update, Delete (CRUD) registered users in PHP system</p>
</div>
</div>
<?php 

 require_once 'footer.php';