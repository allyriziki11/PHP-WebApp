<?php 
 
$localhost 	= "localhost"; 
$username 	= "id14864039_allyriziki12"; 
$password 	= "Rizi_21760719"; 
$dbname 	= "id14864039_crud"; 
 
$con = new mysqli($localhost, $username, $password, $dbname); 

if($con->connect_error) {
    die("connection failed : " . $con->connect_error);
} 
 
/* end of file */