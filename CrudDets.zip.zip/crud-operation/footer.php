<hr>
<div class="container">
	web developer: Riziki Ally; updated&copy; 2020<br />
	<b><i>for more info's checks in below social media accounts:</i></b><br />
	<!-- Add font awesome icons -->
<a href="#" class="fa fa-facebook"></a> facebook-account: Riziki Ally<br />
<a href="#" class="fa fa-instagram"></a> instagram-account: @allyriziki11<br />
<a href="#" class="fa fa-yahoo"></a> yahoo-mail: rizikially384@yahoo.com<br />
<a href="#" class="fa fa-twitter"></a> twitter-account: allyriziki11<br />
<a href="#" class="fa fa-google"></a> google-mail: allyriziki11@gmail.com<br />
</div>
</body>
</html>