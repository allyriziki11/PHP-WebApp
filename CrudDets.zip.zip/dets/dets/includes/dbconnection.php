<?php
$con=mysqli_connect("localhost", "id14864039_allyriziki11", "Rizi_21760719", "id14864039_dets");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

  ?>
