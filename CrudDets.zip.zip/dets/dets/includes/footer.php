<div class="col-sm-12">
				<p class="back-link">Daily Expenses Management System <a href="https://huboftutorials.com">Hub of Tutorials</a>
			<div class="alignleft">
     <script type="text/javascript">
       	amzn_assoc_ad_type = "banner";
	amzn_assoc_marketplace = "amazon";
	amzn_assoc_region = "US";
	amzn_assoc_placement = "assoc_banner_placement_default";
	amzn_assoc_campaigns = "amzn_music_bounty";
	amzn_assoc_banner_type = "category";
	amzn_assoc_isresponsive = "true";
	amzn_assoc_banner_id = "1GTA90RTC5R9V7HJA902";
	amzn_assoc_tracking_id = "fashion120eb-20";
	amzn_assoc_linkid = "c08e19baee7fb40a6f2aef3702ff26cf";
     </script>
     <script src="//z-na.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&Operation=GetScript&ID=OneJS&WS=1"></script>
    </div></p>
			</div>
			
